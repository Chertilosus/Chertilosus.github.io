import subprocess
from openpyxl import load_workbook, Workbook
import os

def get_max_similar():
    output = subprocess.check_output(['race', 'config.toml'], text=True).split('\n')
    max_similar = 0
    for line in output:
        if 'Similar:' in line:
            similar = int(line.split(':')[1].strip())
            max_similar = max(max_similar, similar)
    return max_similar

# Получаем результаты и сразу выводим
results = []
for test in range(15):
    max_similar = get_max_similar()
    results.append(max_similar)
    print(f"Test {test+1}: {max_similar}")  # Сразу выводим результат каждого теста

# Записываем одной строкой для Excel копирования
print("\nExcel row:", end=" ")
print(*results, sep=" ")

# Работа с Excel
filename = 'results.xlsx'
if os.path.exists(filename):
    wb = load_workbook(filename)
    ws = wb.active
    next_row = ws.max_row + 1
else:
    wb = Workbook()
    ws = wb.active
    next_row = 1

for col, value in enumerate(results, 1):
    ws.cell(row=next_row, column=col, value=value)

wb.save(filename)
